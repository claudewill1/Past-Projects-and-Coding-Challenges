const express = require('express');
const ideasRouter = express.Router();

module.exports = ideasRouter;

// create an object of methods imported from the ./db.js file
const {
    getAllFromDatabase,
    getFromDatabaseById,
    addToDatabase,
    updateInstanceInDatabase,
    deleteFromDatabaseById
} = require('./db');

const checkMillionDollarIdea = require('./checkMillionDollarIdea');


ideasRouter.param('id', (req, res, next, id) => {
    const idea = getFromDatabaseById('ideas', id);
    if (idea) {
      req.idea = idea;
      next();
    } else {
      res.status(404).send();
    }
  });


// Get an array of all ideas
ideasRouter.get('/',(req,res,next)=>{
    const allIdeas = getAllFromDatabase('ideas');
    res.send(allIdeas);
});



// Get a single idea by id
ideasRouter.get('/:id',(req,res,next)=>{
    res.send(req.idea);
});

// Add new idea to database
ideasRouter.post('/',checkMillionDollarIdea,(req,res,next)=>{
    const newIdea = addToDatabase('ideas',req.body);
    res.status(201).send(newIdea);
    
});

// update a single idea by id
ideasRouter.put('/:id',checkMillionDollarIdea,(req,res,next)=> {
    const updateIdea = updateInstanceInDatabase('ideas',req.body)
    res.send(updateIdea);
       
});

// delete single minion by id
ideasRouter.delete('/:id',(req,res,next)=> {
    const deletedMinion = deleteFromDatabasebyId('ideas', req.params.ideaId);
    if (deletedMinion) {
        res.status(204);
    } else {
        res.status(500);
    }
    res.send();
});




