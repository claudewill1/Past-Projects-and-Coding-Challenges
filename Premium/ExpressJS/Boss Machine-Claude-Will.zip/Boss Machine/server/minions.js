const express = require('express');
const minionsRouter = express.Router();

module.exports = minionsRouter;

// create an object of methods imported from the ./db.js file
const {
    getAllFromDatabase,
    getFromDatabaseById,
    addToDatabase,
    updateInstanceInDatabase,
    deleteFromDatabaseById
} = require('./db');

minionsRouter.param('minionId', (req, res, next, id) => {
    const minion = getFromDatabaseById('minions', id);
    if (minion) {
      req.minion = minion;
      next();
    } else {
      res.status(404).send();
    }
});

// get an array of all minions
minionsRouter.get('/',(req,res,next)=>{
    res.send(getAllFromDatabase('minions'));
});

//get a single minion by id
minionsRouter.get('/:minionId',(req,res,next)=>{
    res.send(req.minion);
});

// create a new minion
minionsRouter.post('/',(req,res,next)=>{
    if(req.body){
        const newMinion = addToDatabase('minions',req.body);
        res.status(201).send(newMinion);
    } else {
        res.status(400).send();
    }
});

// update a minion by id
minionsRouter.put('/:minionId',(req,res,next)=>{
    const updateMinion = updateInstanceInDatabase('minions',req.body);
    res.send(updateMinion);
    
});

// delete a single minion by id
meetingsRouter.delete('/:minionId',(req,res,next)=>{
    const deleteMinion = deleteFromDatabaseById('minions',req.params.minionId);
    if(deleteMinion){
        res.sendStatus(204);
    } else {
        res.sendStatus(500);
    }
});


